package com.davinci.etone.omc;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.text.format.DateFormat;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;

public class ViewHolderMessages extends RecyclerView.Adapter<ViewHolderMessages.viewHolder> {
    Context context;
    String type;
    ArrayList<Message> list;
    String userId;
    private FirebaseDatabase Db=FirebaseDatabase.getInstance();
    DatabaseReference refMes=Db.getReference().child("Message");

    public ViewHolderMessages(Context context, ArrayList<Message> list,String type,String userId) {
        this.context = context;
        this.list = list;
        this.type = type;
        this.userId = userId;

    }

    @NonNull
    @Override
    public ViewHolderMessages.viewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
    View v= LayoutInflater.from(context).inflate(R.layout.item_message,viewGroup,false);
        return new ViewHolderMessages.viewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolderMessages.viewHolder viewHolder, int position) {
        final Message message=list.get(position);
        viewHolder.date.setText(getDate(message.getDate_envoi()));
        viewHolder.Message.setText(message.getContenu());
        if (message.getEmetteur().equals(userId)){
            viewHolder.container2.setBackgroundResource(R.drawable.border_rect_gris_2);
            viewHolder.container1.setGravity(Gravity.END);
            viewHolder.usr.setVisibility(View.GONE);
        }
        else {
            viewHolder.container2.setBackgroundResource(R.drawable.border_rect_bleu);
            viewHolder.container1.setGravity(Gravity.START);
            viewHolder.usr.setVisibility(View.GONE);
        }
        if(!type.equals("forum"))
            viewHolder.usr.setVisibility(View.GONE);
        else if(!message.getEmetteur().equals(userId)){
            Db.getReference().child("User").child(message.getEmetteur()).addValueEventListener(new ValueEventListener() {
                 @Override
                 public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                     viewHolder.usr.setText(dataSnapshot.child("nom").getValue(String.class));
                 }

                 @Override
                 public void onCancelled(@NonNull DatabaseError databaseError) {

                 }
             });
        }
        if(message.getEmetteur().equals("0") & message.getContenu().contains("Id :")){
            String mil_id=message.getContenu().split("Id :")[1];
            viewHolder.container1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent= new Intent(view.getContext(),Activity_personnel.class);
                    intent.putExtra("pers_id", mil_id);
                    view.getContext().startActivity(intent);
                }
            });
        }

    }

    @Override
    public int getItemCount() {
        return this.list.size();
    }

    public static class viewHolder extends RecyclerView.ViewHolder{
        TextView date,Message,usr;
        RelativeLayout container1,container2;

        public viewHolder(@NonNull View itemView) {
            super(itemView);

            date=itemView.findViewById(R.id.date);
            container1=itemView.findViewById(R.id.container1);
            container2=itemView.findViewById(R.id.container2);
            Message=itemView.findViewById(R.id.message);
            usr=itemView.findViewById(R.id.user);

        }
    }

    private String getDate(long time) {
        java.util.Calendar cal = java.util.Calendar.getInstance(Locale.ENGLISH);
        cal.setTimeInMillis(time * 1000);
        long currentTime=System.currentTimeMillis()/1000;
        java.util.Calendar calcurrent = java.util.Calendar.getInstance(Locale.getDefault());
        calcurrent.setTimeInMillis(currentTime * 1000);
        int dayTime= cal.get(Calendar.DAY_OF_WEEK);
        int daycur= calcurrent.get(Calendar.DAY_OF_WEEK);
        Log.i("Date","Date day of the week "+daycur);
        if (currentTime-time<(24*3600) & daycur==dayTime) {
            String date = DateFormat.format("kk:mm", cal).toString();
            return date;
        }
        if(daycur-dayTime<2 & currentTime-time<2*(24*3600) ){
            String date = DateFormat.format("kk:mm", cal).toString();
            date = "Hier "+ date;
            return date;
        }
        String date = DateFormat.format("dd/MM/yyyy", cal).toString();
        String hour = DateFormat.format("hh:mm", cal).toString();
        date = date+" "+hour;
        return date;
    }
}
